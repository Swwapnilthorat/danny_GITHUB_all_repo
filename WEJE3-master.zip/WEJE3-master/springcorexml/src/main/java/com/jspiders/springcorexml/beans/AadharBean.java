package com.jspiders.springcorexml.beans;

import lombok.Data;

@Data
public class AadharBean {
	
	private int id;
	private long aadhar_no;
	private String date_of_issue;

}
