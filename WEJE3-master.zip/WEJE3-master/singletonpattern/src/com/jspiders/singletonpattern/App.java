package com.jspiders.singletonpattern;

public class App {

}
