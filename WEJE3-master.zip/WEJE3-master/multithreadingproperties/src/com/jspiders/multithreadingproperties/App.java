package com.jspiders.multithreadingproperties;

public class App {

}
