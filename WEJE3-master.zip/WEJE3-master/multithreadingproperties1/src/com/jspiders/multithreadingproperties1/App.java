package com.jspiders.multithreadingproperties1;

public class App {

}
