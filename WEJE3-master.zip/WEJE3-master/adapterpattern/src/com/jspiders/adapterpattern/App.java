package com.jspiders.adapterpattern;

public class App {

}
