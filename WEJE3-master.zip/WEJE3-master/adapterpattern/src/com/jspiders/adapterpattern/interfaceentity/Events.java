package com.jspiders.adapterpattern.interfaceentity;

public interface Events {
	
	void childrensDay();

}
