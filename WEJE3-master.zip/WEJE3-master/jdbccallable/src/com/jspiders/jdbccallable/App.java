package com.jspiders.jdbccallable;

public class App {

}
