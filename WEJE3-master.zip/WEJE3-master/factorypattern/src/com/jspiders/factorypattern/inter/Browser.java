package com.jspiders.factorypattern.inter;

public interface Browser {
	
	void start();

}
