package com.jspiders.multithreadingwaitandnotify1;

public class App {

}
