package com.jspiders.factorypattern.order;

public interface Order {
	
	void orderItem();

}
