package com.jspiders.hibernate;

/**
 * Hello world!
 *
 */
public class App 
{
   
}
