package com.jspiders.array2d;

public class App {

}
