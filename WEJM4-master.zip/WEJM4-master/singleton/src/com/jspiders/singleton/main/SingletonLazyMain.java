package com.jspiders.singleton.main;

import com.jspiders.singleton.object.SingletonLazy;

public class SingletonLazyMain {
	
	public static void main(String[] args) {
		
		SingletonLazy.getObject();
		SingletonLazy.getObject();
		SingletonLazy.getObject();
		SingletonLazy.getObject();
		
	}

}
