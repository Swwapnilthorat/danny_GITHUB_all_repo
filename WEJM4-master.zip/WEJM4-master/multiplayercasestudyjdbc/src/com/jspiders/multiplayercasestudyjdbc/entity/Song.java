package com.jspiders.multiplayercasestudyjdbc.entity;

public class Song {

}
