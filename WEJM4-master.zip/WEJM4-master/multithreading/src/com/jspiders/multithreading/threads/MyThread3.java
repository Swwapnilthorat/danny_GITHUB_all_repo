package com.jspiders.multithreading.threads;

public class MyThread3 extends Thread {

	@Override
	public void run() {
		System.out.println("MyThread3 is now running");
	}
}
