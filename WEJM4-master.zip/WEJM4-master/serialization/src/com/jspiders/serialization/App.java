package com.jspiders.serialization;

public class App {

}
