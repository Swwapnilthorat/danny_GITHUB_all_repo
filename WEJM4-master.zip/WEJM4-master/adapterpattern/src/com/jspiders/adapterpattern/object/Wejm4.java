package com.jspiders.adapterpattern.object;

public class Wejm4 {
	
	int id;
	
	String name;
	
	String tech_rating;
	
	String comm_rating;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getTech_rating() {
		return tech_rating;
	}

	public void setTech_rating(String tech_rating) {
		this.tech_rating = tech_rating;
	}

	public String getComm_rating() {
		return comm_rating;
	}

	public void setComm_rating(String comm_rating) {
		this.comm_rating = comm_rating;
	}

}
