package com.jspiders.adapterpattern.interfaces;

public interface Mock {
	
	void rating();

}
