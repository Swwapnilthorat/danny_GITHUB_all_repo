package com.jspiders.springcorexml.beans;

import lombok.Data;

@Data
public class ChildBean {
	
	private int id;
	private String name;
	private int age;

}
