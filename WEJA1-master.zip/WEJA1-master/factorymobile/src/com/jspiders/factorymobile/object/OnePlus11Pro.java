package com.jspiders.factorymobile.object;

import com.jspiders.factorymobile.mobile.Mobile;

public class OnePlus11Pro implements Mobile {

	@Override
	public void order() {
		System.out.println("Ordered OnePlus 11 Pro.");
	}

}
