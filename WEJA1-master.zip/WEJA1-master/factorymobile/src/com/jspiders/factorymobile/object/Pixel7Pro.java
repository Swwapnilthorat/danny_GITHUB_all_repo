package com.jspiders.factorymobile.object;

import com.jspiders.factorymobile.mobile.Mobile;

public class Pixel7Pro implements Mobile {

	@Override
	public void order() {
		System.out.println("Ordered Pixel 7 Pro.");
	}

}
