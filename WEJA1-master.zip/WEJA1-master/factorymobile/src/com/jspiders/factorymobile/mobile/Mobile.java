package com.jspiders.factorymobile.mobile;

public interface Mobile {
	
	void order();

}
