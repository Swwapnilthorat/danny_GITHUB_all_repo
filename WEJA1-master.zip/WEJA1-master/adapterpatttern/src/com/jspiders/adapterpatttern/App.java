package com.jspiders.adapterpatttern;

public class App {

}
