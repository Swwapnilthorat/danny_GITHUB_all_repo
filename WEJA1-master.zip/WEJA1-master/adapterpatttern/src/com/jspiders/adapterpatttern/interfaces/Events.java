package com.jspiders.adapterpatttern.interfaces;

public interface Events {
	
	void mothersDay();
	
	void fathersDay();

}
