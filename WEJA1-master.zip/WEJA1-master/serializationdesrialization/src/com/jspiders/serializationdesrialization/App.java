package com.jspiders.serializationdesrialization;

public class App {

}
