package com.jspiders.springcorexml.beans;

import lombok.Data;

@Data
public class TrainBean {
	
	private int id;
	private int train_no;
	private String name;

}
