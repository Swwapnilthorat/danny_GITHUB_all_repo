package com.jspiders.springcorexml.beans;

import lombok.Data;

@Data
public class DriverBean {
	
	private int id;
	private String name;
	private long contact;

}
