package com.jspiders.springrest;

public class App {

}
