package com.jspiders.factorypattern;

public class App {

}
