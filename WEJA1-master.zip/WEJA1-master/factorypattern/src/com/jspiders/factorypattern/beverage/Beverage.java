package com.jspiders.factorypattern.beverage;

public interface Beverage {
	
	void order();

}
