package com.jspiders.jdbcdynamic;

public class App {

}
