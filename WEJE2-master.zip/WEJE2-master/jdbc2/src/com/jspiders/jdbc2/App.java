package com.jspiders.jdbc2;

public class App {

}
