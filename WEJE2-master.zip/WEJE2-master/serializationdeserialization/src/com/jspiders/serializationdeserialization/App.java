package com.jspiders.serializationdeserialization;

public class App {

}
