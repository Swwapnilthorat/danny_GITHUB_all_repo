package com.jspiders.designpatternstask;

public class App {

}
