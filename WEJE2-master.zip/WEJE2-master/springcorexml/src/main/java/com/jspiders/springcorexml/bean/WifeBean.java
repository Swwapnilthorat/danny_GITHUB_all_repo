package com.jspiders.springcorexml.bean;

import lombok.Data;

@Data
public class WifeBean {
	
	private int id;
	private String name;
	private int age;

}
