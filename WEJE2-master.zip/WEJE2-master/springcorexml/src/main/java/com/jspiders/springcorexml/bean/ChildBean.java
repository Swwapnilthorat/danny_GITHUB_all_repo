package com.jspiders.springcorexml.bean;

import lombok.Data;

@Data
public class ChildBean {

	private int id;
	private String name;
}
