package com.jspiders.springcorexml.bean;

import lombok.Data;

@Data
public class ProductBean {
	
	private int id;
	
	private String name;

}
