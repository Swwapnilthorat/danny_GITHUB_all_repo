package com.jspiders.springcorexml.bean;

import lombok.Data;

@Data
public class FatherBean1 {
	
	private int id;
	private String name;

}
