package com.jspiders.singleton;

public class App {

}
