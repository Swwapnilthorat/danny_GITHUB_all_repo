package com.jspiders.adapterpattern.interfaces;

public interface CompanyEvents {
	
	void womensDay();

}